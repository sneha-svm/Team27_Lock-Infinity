<?php

	define('BASEURL', $_SERVER['DOCUMENT_ROOT'].'/internship/');
	define('CART_COOKIE', 'Sum123Am1902intern');
	define('CART_COOKIE_EXPIRE',time() + (86400 *30));
	define('TAXRATE', 0.18);
?>